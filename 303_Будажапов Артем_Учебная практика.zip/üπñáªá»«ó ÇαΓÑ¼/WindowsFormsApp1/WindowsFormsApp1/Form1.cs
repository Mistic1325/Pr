﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OpenTK;
using OpenTK.Graphics;
using OpenTK.Graphics.OpenGL;


namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        double ScreenW, ScreenH; //Размеры окна

        private float devX; //Отношение сторон окна визуализации
        private float devY; //Для корректного перевода координат мыши в координаты, принятые в программе

        private float[,] GrapValueArray; // массив, который будет хранить значения x, y точек графика

        private int element_count = 0; //количество элементов в массиве

        private bool not_calculate = true; //флаг, означающий, что массив с значениями координат графика пока еще не заполнен

        private int pointPosition = 0; //номер ячейки массива, из которой будут взфты координаты для красной точки, для визуализаци текущего кадра

        float lineX, lineY; //вспомогательные переменные для построения линий от курсора мыши к координатным осям

        float Mcoord_X = 0, Mcoord_Y = 0; //Текущие координаты курсора мыши

        private void AnT_Load(object sender, EventArgs e)
        {
            GL.Viewport(0, 0, AnT.Width, AnT.Height);
            GL.MatrixMode(MatrixMode.Projection);
            GL.LoadIdentity();
            GL.Ortho(0.0, 30.0 * (float)AnT.Width / (float)AnT.Height, 0.0, 30.0, -1, 1);
            GL.MatrixMode(MatrixMode.Modelview);
        }

        private void AnT_MouseMove(object sender, MouseEventArgs e)
        {
            //Сохраняем координаты мыши
            Mcoord_X = e.X;
            Mcoord_Y = e.Y;

            //вычисляем параметры для будущей дорисовки линий от указателя мыши к координатным осям
            lineX = devX * e.X;
            lineY = (float)(ScreenH - devY * e.Y);

        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Определение параметров настройки проекции, в зависимости от размеров сторон элемента AnT (GLControl)
            if ((float)AnT.Width <= (float)AnT.Height)
            {
                ScreenW = 30.0;
                ScreenH = 30.0 * (float)AnT.Height / (float)AnT.Width;
                GL.Ortho(0.0, ScreenW, 0.0, ScreenH, -1, 1);
            }
            else
            {
                ScreenH = 30.0;
                ScreenW = 30.0 * (float)AnT.Width / (float)AnT.Height;
                GL.Ortho(0.0, 30.0 * (float)AnT.Width / (float)AnT.Height, 0.0, 30.0, -1, 1);
            }

            //сохранение коэффициентов, которые нам необходимы для перевода координат указателя в оконной системе, в координаты принятые в нашей OpenGL сцене
            devX = (float)ScreenH / (float)AnT.Width;
            devY = (float)ScreenW / (float)AnT.Height;

            GL.MatrixMode(MatrixMode.Modelview); //Установка объектно-видовой матрицы

            PointIngrap.Start(); //Старт счетчика, отвечающего за вызов функции визуализации сцены
        }

        private void PointIngrap_Tick(object sender, EventArgs e)
        {
            //если мы долшли до последнего значения массива
            if (pointPosition == element_count - 1)
                pointPosition = 0; //Переходим к начальному элементу

            Draw(); //функция визуализации

            pointPosition++; //переход к следующему элементу массива
        }

        private void functionalCalculation()
        {
            float x = 0, y = 0; //Определение локадьных переменных x и y

            GrapValueArray = new float[300, 2]; //Инициализация массива, который будет хранить значение 300 точек из которых будет состоять график

            element_count = 0; //счетчик элементов массива

            //Вычисление всех значение y, для xпринадлежащего промежутка от -1 до 3 с шагом в 0.01f
            for (x=-15; x<15; x+= 0.1f) //вычисление yдля текущего x
            {
                //y=x*x*(x-2)*(x-2);
                y = ... //строка, описывающая график функции y=f(x)

                    GrapValueArray[...] = ... //запись в массив координат x и y

                    elements_count++; //подсчет элементов
            }
            not_calculate = false; //изменение флага, сигнализирующего о вычислении значений функции
        }
        private void DrawDiagram()
        {
            if (not_calculate) //Проверка флага, сигнализирующего о том, что координаты графика вычислены
            {
                functionalCalculation(); //Если нет - то вызываем функцию вычисления координат графика
            }

            //Стартуем отрисовку в режиме визауализации точек объединяемые в линии
            GL.Begin(PrimitiveType.LineStrip);
            GL.Vertex2(GrapValueArray[0, 0], GrapValueArray[0, 1]); //Рисуем начальную точку
            for (int ax = 1; ax < element_count; ax +=2) //Проходим по массиву с координатами вычисленных точек
            {
                GL.Vertex2(GrapValueArray[ax, 0], GrapValueArray[ax, 1]); //передаем в OpenGL инфу о вершине, участвующей в построении линий
            }
            GL.End(); //Заверщаем режим рисования

            GL.PointSize(5); //устанавливаем размер точки, равный 5 пикселям

            GL.Color3(Color.Red); //устанавливаем текущим цветом - красный цвет

            GL.Begin(PrimitiveType.Points); //активируем режим вывода точек

            //Выводим красную точку, используя ту ячейку массива, до которой мы дошли (вычисляется в функции обработчике событий таймер)
            GL.Vertex2(GrapValueArray[pointPosition, 0], GrapValueArray[pointPosition, 1]);

            GL.End(); //Заверщаем режим рисования

            GL.PointSize(1); //Устанавливаем размер точку равный единице
        }

        private void Draw()
        {
            GL.ClearColor(Color.Bisque); //Заливка окна вывода и очистка буфера глубины

            //очистка буфера цвета и буфера глубины
            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);
            GL.LoadIdentity(); //очищение текущей матрицы
            GL.Color3(0, 0, 0); //установка черного цвета
            GL.PushMatrix(); //помещаем состояние матрицы в стек матриц
            GL.Translate(20, 15, 0); //Выполняем перемещение в пронстранстве по осям X и Y
            GL.Begin(PrimitiveType.Points); //активируем режим рисования

            //с помощью прохода двумя циклами, создаем сетку их точек
            for (float ax=-15; ax<15; ax++)
            {
                for (float bx = -15; bx < 15; bx++)
                {
                    GL.Vertex2(ax, bx); //Вывод точки
                }
            }
            GL.End();

            GL.Begin(PrimitiveType.Lines); //активируем режим рисования, каждые 2 последовательно вызванные команды Vertex объединяются в линии

            //далее мы рисуем координаты оси и стрелкки на их концах
            GL.Vertex2(0, -15);
            GL.Vertex2(0, 15);
            GL.Vertex2(-15, 0);
            GL.Vertex2(15, 0);

            //Вертикальные стрелки
            GL.Vertex2(0, 15);
            GL.Vertex2(0.1, 14.5);
            GL.Vertex2(0, 15);
            GL.Vertex2(-0, 14.5);

            //Горизонтальные стрелки
            GL.Vertex2(15, -15);
            GL.Vertex2(14.5, 0.1);
            GL.Vertex2(15, 0);
            GL.Vertex2(14.5, -0.1);

            GL.End();

            DrawDiagram(); //Вызываем функцию рисования графика
            GL.PopMatrix(); //Возвращаем матрицу из стека

            GL.Color3(Color.Red);
            GL.Begin(PrimitiveType.Lines);
            GL.Vertex2(lineX, 15);
            GL.Vertex2(lineX, lineY);
            GL.Vertex2(20, lineY);
            GL.Vertex2(lineX, lineY);
            GL.End();

            AnT.SwapBuffers(); //переключаем буфер вывода
        }
    }
}
